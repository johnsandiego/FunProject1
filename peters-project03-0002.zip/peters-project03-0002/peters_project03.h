/* 
 * Machine Variables
 */

char IR[6]; 		// Instruction register; holds the current line of the program.
short int PC = 0; 	// Program counter; contains the current line number of the program.
int BAR = 0;        // Base Address Register; minimum legal address of current executing process
int LR = 99;        // Limit Register; highest legal address of current executing process
int EAR = 0;		// Effective Address Register; actual physical address
int IC = 0;         // Instruction Counter Register; counts down to 0, when 0 preempts current process

// Pointer registers
short int P0 = 0; 
short int P1 = 0;
short int P2 = 0;
short int P3 = 0;

// General purpose registers
int R0 = 0; 
int R1 = 0;
int R2 = 0;
int R3 = 0;

int ACC = 0;              // Accumulator
char PSW[2] = {'F', 'Z'}; // Process Status Word

#define memSize 500              // easily accessible main memory size value
char memory[memSize][6];		 // Main virtual machine "memory"
short int opcode;     			 // The current opcode (used for manipulation and reference)
int program_line = 0;			 // Current line of the program -- useful for multitasking recall.
int currentPID;                  // Currently executing process's ID

/*
 * Variables that exist to faciliate the virtual machine's interaction with the host machine -- and the VM's existence itself!
 */
int fp; 
int i; 
char input_line [7];
struct PCB *RQ = NULL;
struct PCB *RQT = NULL;
struct semaphore *Doorman;
struct semaphore *Forks[5];

/*
 * Functions!
 */

int main(int argc, char *argv[]);

void setClear();

void openProgs(int philosopherType, int timeType);

int loadProgToMem(char n[], int timeType);

void parseOpCode();

int memToDec(int memoryLine, int byteCoupletNumber);

void decToMem(int decimalValue, int memoryLine);

void runRoundRobin();

void runProgByLine();

void printMem();

// pops currently executing process from RQ
void pop_from_RQ();

// saves VM state to currently executing PCB
void save_VM_to_PCB();

// loads head of RQ to VM variables
void load_RQ_to_VM();

// ------------------------------------------- PBRAIN ------------------------------------------- // 

// Switch/Case block that directs execution of the correct opcode
void opcodeSwitch(int op);

// Load Pointer: Immediate addr
void Load_PTR_IMM(); // 00

// Add to Pointer: Immediate addr
void Add_PTR_IMM();  // 01 

// Subtract from Pointer: Immediate addr
void Sub_PTR_IMM();  // 02

// Load Accumulator: Immediate addr
void Load_ACC_IMM(); // 03

// Load Accumulator: Register addr
void Load_ACC_REG(); // 04

// Load Accumulator: Direct addr
void Load_ACC_DIR(); // 05

// Store Accumulator: Register addr
void Stor_ACC_REG(); // 06

// Store Accumulator: Direct addr
void Stor_ACC_DIR(); // 07

// Store Register to Memory: Register addr
void Stor_REG2MEM_REG(); // 08

// Store Register to Memory: Direct addr
void Stor_REG2MEM_DIR(); // 09

// Load Register from Memory (mem to reg): Register addr
void Load_MEM2REG_REG(); // 10

// Load Register from Memory (mem to reg): Direct addr
void Load_MEM2REG_DIR(); // 11

// Load Register R0: Immediate addr
void Load_REGr0_IMM(); // 12

// Register to Register Transfer
void REG2REG(); // 13

// Load Accumulator from Register (reg to acc)
void Load_REG2ACC(); // 14

// Load Register from Accumulator (acc to reg)
void Load_ACC2REG(); // 15

// Add Accumulator: Immediate addr
void Add_ACC_IMM(); // 16

// Subtract Accumulator: Immediate addr
void Sub_ACC_IMM(); // 17

// Add contents of Register to Accumulator
void Add_REG2ACC(); // 18

// Subtract contents of Register from Accumulator
void Sub_REG_ACC(); // 19

// Add Accumulator: Register addr
void Add_2ACC_REG(); // 20

// Add Accumulator: Direct addr
void Add_2ACC_DIR(); // 21

// Subtract from Accumulator: Register addr
void Sub_ACC_REG(); // 22

// Subtract from Accumulator: Direct addr
void Sub_ACC_DIR(); // 23

// Compare Equal: Register addr
void Comp_EQL_REG(); // 24

// Compare Less: Register addr
void Comp_LESS_REG(); // 25

// Compare Greater: Register addr
void Comp_GRT_REG(); // 26

// Compare Greater: Immediate addr
void Comp_GRT_IMM(); // 27

// Compare Equal: Immediate addr
void Comp_EQL_IMM(); // 28

// Compare Less: Immediate addr
void Comp_LESS_IMM(); // 29

// Compare Register Equal
void Comp_REG_EQL(); // 30

// Compare Register Less
void Comp_REG_LESS(); // 31

// Compare Register Greater
void Comp_REG_GRT(); // 32

// Branch Conditional: True
void Branch_Cond_T(); // 33

// Branch Conditional: False
void Branch_Cond_F(); // 34

// Branch Unconditional
void Branch_Uncond(); // 35

// Trap
void Trap(); // 36

// semaphore_wait "system call"
void semaWait();

// semaphore_post "system call"
void semaSignal();

// get PID "system call"
void getPID();

// Modulus 
void Mod();  // 37

// Halt
void Halt(); // 99

// Shutdown the VM
int shutDown();

struct PCB
{
	int PID;                          // Name of PCB
	char progName[5];                 // Name of program loaded into PCB
	struct PCB *Next_PCB;             // Pointer to next PCB
	int R0, R1, R2, R3;               // General Purpose Registers
	short int PC, P0, P1, P2, P3;     // Progam Counter, Pointer Registers
	int BAR, EAR, LR;                 // Multitasking Registers
	int ACC;						  // Accumulator
	char PSW[2];					  // Process Status Word
	int IC;                           // Instruction Counter
}; // end struct PCB

struct semaphore
{ 
	int count;
  	struct PCB *Sem_Q;
};