#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include "peters_project03.h"

/*
 * Main VM function
 */
int main(int argc, char *argv[])
{
	// initialized the semaphores central to this project
	Doorman = (struct semaphore*)malloc( sizeof(struct semaphore) );
	Doorman->count = 4;
	for (i = 0; i < 5; i++)
	{
		Forks[i] = (struct semaphore*)malloc(sizeof(struct semaphore));
		Forks[i]->count = 1;
	}
	
	// continues VM operation as usual
	srand(time(NULL));
	setClear();
	openProgs(atoi(argv[1]), atoi(argv[2]) ); // (int)argv[1]);
	runRoundRobin();
	shutDown();
}

/*
 * Instantiates all memory locations to 'x' -- fresh slate, no gibberish! 
 */
void setClear()
{	
	
	int j;
	for (i = 0; i < memSize; i ++)
	{
		for (j = 0; j < 6; j++)
		{
			memory[i][j] = 'x';
		}
	}
}

/*
 * Opens all 5 philosopher programs of specified philosopherType -- 0 is mediocre philosophers, 1 is deadlock-proof philosopher
 */
void openProgs(int philosopherType, int timeType)
{
	char name[5];
	for (i = 0; i < (memSize/100); i++)
	{
		BAR = (i * 100);
		printf("BAR = %d\n", BAR);
		LR = (BAR + 99);
		snprintf(name, 5, "PT.%d", (philosopherType));
		
		fp = open(name, O_RDONLY); 

	 	if (fp < 0)	// Handles an error in the file read operation
	    {
			printf("Could not open %c%c%c%c%c\n", name[0], name[1], name[2], name[3], name[4]);
	        exit(0);
	    }
		
		if (loadProgToMem(name, timeType) != 1)
		{
			printf("Error loading PhilosopherType.%d to memory, exiting VM.\n", philosopherType);
			exit(0);
		}	
		close(fp);
	}
	RQT->Next_PCB = RQ;
}

/*
 * Read program into VM memory
 */
int loadProgToMem(char n[], int timeType)
{
	int ret = read (fp, input_line, 7 ); // Read first line of program
	program_line = 0;
	int i;
	
	while (1) // Continue reading the program into memory until break()
	{ 
		if (ret <= 0)	// Signals that interpreter has reached the end of the PBRAIN file
		{
			break; 		// Breaks free of read program loop
		}
		
		//Copies program, line-by-line, into program memory. 
		EAR = BAR + program_line;
		for (i = 0; i < 6 ; i++)
		{
        	memory[EAR][i] = input_line[i]; 
		}
	   
       	ret = read (fp, input_line, 7 );  // Read in next line of code
       	program_line++;
    } // end of while(1) -- read file line-by-line
	
	if (RQ == NULL)
	{
		RQ = (struct PCB*)malloc(sizeof(struct PCB));
		RQT = RQ;
		RQ->Next_PCB = NULL;
		RQ->PID = 1;
	}
	else
	{
		int i = 2;
		struct PCB *ptr = RQ;
		while (ptr->Next_PCB != NULL)
		{
			ptr = ptr->Next_PCB;
			i++;
		}
		ptr->Next_PCB = (struct PCB*)malloc(sizeof(struct PCB));
		RQT = ptr->Next_PCB;
		RQT->Next_PCB = NULL;
		RQT->PID = i;
	} // end of if/else -- build Ready Queue linked list
	
	switch (timeType) // assigns each process the specified time quantum.
	{
		case 0: RQT->IC = 1;
			break;
		case 1: RQT->IC = 20;
			break; 
		case 2: RQT->IC = ( (rand() % 10) + 1);                            
			break;
		default: RQT->IC = ( (rand() % 10) + 1); 
			break;
	}
		
	RQT->BAR = BAR;
	RQT->EAR = EAR;
	RQT->LR = (BAR + 99);
	RQT->PC = 0;
	int k;
	for (k = 0; k < 5; k ++)
	{
		RQT->progName[k] = n[k];
	}
	return 1; // Returns 1 if program loaded successfully
}

/*
 * Reads char version of the opcode, converts to decimal
 */
void parseOpCode()
{
	for (i = 0; i < 6; i++)
	{
		IR[i] = (memory[PC + BAR][i]);
	}
	opcode = (IR[0] - 48) * 10;
	opcode += (IR[1] - 48);
} 

/*
 * Reads a given couplet from given line of memory, converts to decimal
 */
int memToDec(int memoryLine, int byteCoupletNumber) // byteCoupletNumber is 0, 1, or 2
{
	int val;
	val = (memory[memoryLine][byteCoupletNumber + 0] -48) * 10;
	val += (memory[memoryLine][byteCoupletNumber + 1] -48);
	return val;
}

/*
 * Writes a decimal value to given line of memory
 */
void decToMem(int decimalValue, int memoryLine)
{ 
	// Separates out each digit, then converts to character representation
	memory[memoryLine][2] = (char)( ( (int) (decimalValue / 1000)  ) + 48); 
	memory[memoryLine][3] = (char)( ( (int) (decimalValue % 1000) / 100 ) + 48); 
	memory[memoryLine][4] = (char)( ( (int) (decimalValue % 100) / 10 ) + 48); 
	memory[memoryLine][5] = (char)( ( (int) (decimalValue ) % 10) + 48);     
	memory[memoryLine][1] = 'Z';
	memory[memoryLine][0] = 'Z';
}

/*
 * Loads the head of the RQ into the VM.  
 *      Note to self: in next version accept pointer to PCB, load from that.
 */
void load_RQ_to_VM()
{
	R0 = RQ->R0; R1 = RQ->R1; R2 = RQ->R2; R3 = RQ->R3;      // Loads the VM General Registers from PCB
	P0 = RQ->P0; P1 = RQ->P1; P2 = RQ->P2; P3 = RQ->P3;      // Loads the VM Pointer Registers from PCB
	BAR = RQ->BAR; EAR = RQ->EAR; LR = RQ->LR; IC = RQ->IC;  // Loads the VM Memory-Assist Registers from PCB
	ACC = RQ->ACC; PSW[0] = RQ->PSW[0]; PSW[1] = RQ->PSW[1]; // Loads the ACC and PSW
	currentPID = RQ->PID;                                    // Loads the current process's ID
	PC = RQ->PC;                                             // Lastly loads the VM PC from PCB
}

/*
 * Saves the machine state into PCB.
 *      Note to self: in next version accept pointer to PCB, save to that.
 */
void save_VM_to_PCB()
{
	RQ->PC = PC;                                             // Firstly saves the VM PC to PCB
	RQ->R0 = R0; RQ->R1 = R1; RQ->R2 = R2; RQ->R3 = R3;      // Saves the VM General Registers to PCB
	RQ->P0 = P0; RQ->P1 = P1; RQ->P2 = P2; RQ->P3 = P3;      // Saves the VM Pointer Registers to PCB
	RQ->BAR = BAR; RQ->EAR = EAR; RQ->LR = LR;				 // Saves the VM Memory-Assist Register to PCB
	RQ->ACC = ACC; RQ->PSW[0] = PSW[0]; RQ->PSW[1] = PSW[1]; // Saves the ACC and PSW
}

/*
 * Removes the current head of the RQ from the RQ
 *      Note to self: in next version use rather than code in runRoundRobin()
 */
void pop_from_RQ()
{
	RQ = RQ->Next_PCB;      // Progresses the RQ ...
	RQT->Next_PCB = RQ;     // ...and points the tail to the new head.
}

/*
 * Runs all loaded programs in a round-robin style
 */
void runRoundRobin()
{
	while (RQ != NULL)
	{
		load_RQ_to_VM();
		printf("\nProcess ID:%02d ready to begin execution (Program: %c%c%c%c%c), with a time slice of %d\n", 
			RQ->PID, RQ->progName[0], RQ->progName[1], RQ->progName[2], RQ->progName[3], RQ->progName[4], IC);
		runProgByLine();
		save_VM_to_PCB();
		
		if (IC < 0) // If current process Halted:
		{	
			if (RQ == RQT) {break;} // If current process halted AND is the last in the linked list, we're done!
			RQ = RQ->Next_PCB;      // Makes the next-to-execute the head of the RQ...
			RQT->Next_PCB = RQ;     // ...and points the tail to the new head.
		} // end of if()
		else // If current process was merely preempted:
		{
			RQT = RQ;               // Makes the current process the new tail of the RQ...
			RQ = RQ->Next_PCB;      // ...and makes the next-to-execute the head of the RQ...
			RQT->Next_PCB = RQ;     // ...and points the new tail to the new head.
		} // end of else
	} // end of while()
	printf("\nNo more programs in Ready Queue.  Done running!\n");
}

/*
 * Runs currently loaded process
 */
void runProgByLine()
{
	while( (PC < 100) && IC > 0) // Will run proccess until time slice is up or HALT is encountered
	{
		if (EAR > LR) // Will halt process before it has the chance to write to memory other than its own!
		{
			printf("Program %c%c%c%c has exceeded its memory bounds.  Halting.", RQ->progName[0], RQ->progName[1], RQ->progName[2], RQ->progName[3]);
			Halt();
		}
		parseOpCode();
		printf("PID = %02d PC = %02d IC = %02d; ", RQ->PID, PC, IC);
		opcodeSwitch(opcode);
		IC --;
	}
}

void opcodeSwitch(int op)
{
	switch (op)
	{
		case 0: Load_PTR_IMM();
			break;
		case 1: Add_PTR_IMM();
			break;
		case 2: Sub_PTR_IMM();
			break;
		case 3: Load_ACC_IMM();
			break;
		case 4: Load_ACC_REG();
			break;
		case 5: Load_ACC_DIR();
			break;
		case 6: Stor_ACC_REG();
			break;
		case 7: Stor_ACC_DIR();
			break;
		case 8: Stor_REG2MEM_REG();
			break;
		case 9: Stor_REG2MEM_DIR();
			break;
		case 10: Load_MEM2REG_REG();
			break;
		case 11: Load_MEM2REG_DIR();
			break;
		case 12: Load_REGr0_IMM();
			break;
		case 13: REG2REG();
			break;
		case 14: Load_REG2ACC();
			break;
		case 15: Load_ACC2REG();
			break;
		case 16: Add_ACC_IMM();
			break;
		case 17: Sub_ACC_IMM();
			break;
		case 18: Add_REG2ACC();
			break;
		case 19: Sub_REG_ACC();
			break;
		case 20: Add_2ACC_REG();
			break;
		case 21: Add_2ACC_DIR();
			break;
		case 22: Sub_ACC_REG();
			break;
		case 23: Sub_ACC_DIR();
			break;
		case 24: Comp_EQL_REG();
			break;
		case 25: Comp_LESS_REG();
			break;
		case 26: Comp_GRT_REG();
			break;
		case 27: Comp_GRT_IMM();
			break;
		case 28: Comp_EQL_IMM();
			break;
		case 29: Comp_LESS_IMM();
			break;
		case 30: Comp_REG_EQL();
			break;
		case 31: Comp_REG_LESS();
			break;
		case 32: Comp_REG_GRT();
			break;
		case 33: Branch_Cond_T();
			break;
		case 34: Branch_Cond_F();
			break;
		case 35: Branch_Uncond();
			break;
		case 36: Trap();
			break;
		case 37: Mod();
			break;
		case 99: Halt();
			break;
		default: printf("IR = %c%c%c%c%c%c.  Encountered unknown opcode.  Oops!  Exiting.\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
			exit(1);
	} // end of switch block
} // end of opcodeSwitch()

// 00 Load Pointer: Immediate addr
void Load_PTR_IMM()
{
	//printf("PC = %2d; IR = %c%c%c%c%c%c; Load Pointer: Immediate addr\n", PC, IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	printf("IR = %c%c%c%c%c%c; Load Pointer: Immediate addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	// Parses immediate value from current instruction line into decimals
	int immediate_value = (int) (IR[4] - 48) * 10;
	immediate_value += (int) (IR[5] - 48);
	
	switch( (IR[3] - 48) ) // Switches based on the provided register number, after converting char to int
	{				
		case 0: P0 = immediate_value;
			break;
		case 1: P1 = immediate_value;
			break;
		case 2: P2 = immediate_value;
			break;
		case 3: P3 = immediate_value;
			break;
	}
	PC ++;
}

// 01 Add to Pointer: Immediate addr
void Add_PTR_IMM()
{
	printf("IR = %c%c%c%c%c%c; Add to Pointer: Immediate addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	// Parses immediate value from current instruction line into decimals
	int immediate_value = (int) (IR[4] - 48) * 10;
	immediate_value += (int) (IR[5] - 48);
	
	switch( (IR[3] - 48) ) // Switches based on the provided register number, after converting char to int
	{	
		case 0: P0 += immediate_value;
			break;
		case 1: P1 += immediate_value;
			break;
		case 2: P2 += immediate_value;
			break;
		case 3: P3 += immediate_value;
			break;
	}
	PC ++;
}

// 02 Subtract from Pointer: Immediate addr
void Sub_PTR_IMM()
{
	printf("IR = %c%c%c%c%c%c; Subtract from Pointer: Immediate addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	// Parses immediate value from current instruction line into decimals
	int immediate_value = (int) (IR[4] - 48) * 10;
	immediate_value += (int) (IR[5] - 48);
	
	switch( (IR[3] - 48) ) // Switches based on the provided register number, after converting char to int
	{		
		case 0: P0 -= immediate_value;
			break;
		case 1: P1 -= immediate_value;
			break;
		case 2: P2 -= immediate_value;
			break;
		case 3: P3 -= immediate_value;
			break;
	}
	PC ++;
}

// 03 Load Accumulator: Immediate addr
void Load_ACC_IMM()
{
	printf("IR = %c%c%c%c%c%c; Load Accumulator: Immediate addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	// Converts provided immediate value to int, then loads into accumulator
	int immediate_value = (int) (IR[2] - 48) * 1000;
	immediate_value += (int) (IR[3] - 48) * 100; 
	immediate_value += (int) (IR[4] - 48) * 10;
	immediate_value += (int) (IR[5] - 48);
	
	ACC = immediate_value;
	PC ++;
}

// 04 Load Accumulator: Register addr
void Load_ACC_REG()
{
	printf("IR = %c%c%c%c%c%c; Load Accumulator: Register addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	int i;
	char memLine[6]; 
	switch( (IR[3] - 48) ) // Switches based on the provided register number, after converting char to int
	{	// Copies the appropriate line of memory into a variable
		case 0: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P0 + BAR][i]; 
			}
			break;
		case 1: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P1 + BAR][i]; 
			}
			break;
		case 2: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P2 + BAR][i]; 
			}
			break;
		case 3: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P3 + BAR][i]; 
			}
			break;
	}
	// Converts the data stored on memory line to int, then loads into accumulator
	int immediate_value = (int) (memLine[2] - 48) * 1000;
	immediate_value += (int) (memLine[3] - 48) * 100; 
	immediate_value += (int) (memLine[4] - 48) * 10;
	immediate_value += (int) (memLine[5] - 48);
	
	ACC = immediate_value;
	PC ++;
}

// 05 Load Accumulator: Direct addr
void Load_ACC_DIR()
{
	printf("IR = %c%c%c%c%c%c; Load Accumulator: Direct addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	// Gets the memory address from the instruction, converts to int
	int addr = (int) (IR[2] - 48) * 10;
	addr += (int) (IR[2] - 48);
	addr += BAR;
	
	// Converts data from memory line to int, loads into accumulator
	int immediate_value = (int) (memory[addr][2] - 48) * 1000;
	immediate_value += (int) (memory[addr][3] - 48) * 100; 
	immediate_value += (int) (memory[addr][4] - 48) * 10;
	immediate_value += (int) (memory[addr][5] - 48);
	
	ACC = immediate_value;
	PC ++;
}

// 06 Store Accumulator: Register addr
void Stor_ACC_REG()
{
	printf("IR = %c%c%c%c%c%c; Store Accumulator: Register addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	int addr;
	switch( (IR[3] - 48) ) // Switches based on the provided register number, after converting char to int
	{				
		case 0: addr = P0 + BAR;
			break;
		case 1: addr = P1 + BAR;
			break;
		case 2: addr = P2 + BAR;
			break;
		case 3: addr = P3 + BAR;
			break;
	}
	decToMem(ACC, addr); 
	PC ++;
}

// 07 Store Accumulator: Direct addr
void Stor_ACC_DIR()
{
	printf("IR = %c%c%c%c%c%c; Store Accumulator: Direct addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	// Converts address to integer, then invokes the decToMem() function to write ACC to memory in char form
	int addr;
	addr = (int) (IR[2] - 48) * 10;
	addr += (int) (IR[3] - 48);
	addr += BAR;
	decToMem(ACC, (addr)); 
	PC ++;
}

// 08 Store Register to Memory: Register addr
void Stor_REG2MEM_REG()
{
	printf("IR = %c%c%c%c%c%c; Store Register to Memory: Register addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	int addr;
	switch( (IR[5] - 48) ) // Switches based on the provided pointer register number, after converting char to int
	{				
		case 0: addr = P0 + BAR;
			break;
		case 1: addr = P1 + BAR;
			break;
		case 2: addr = P2 + BAR;
			break;
		case 3: addr = P3 + BAR;
			break;
	}
	
	switch( (IR[3] - 48) ) // Switches based on the provided general register number, copies appropriate regist to memory line
	{				
		case 0: decToMem(R0, addr);
			break;
		case 1: decToMem(R1, addr);
			break;
		case 2: decToMem(R2, addr);
			break;
		case 3: decToMem(R3, addr);
			break;
	}
	PC ++;
}

// 09 Store Register to Memory: Direct addr
void Stor_REG2MEM_DIR()
{
	printf("IR = %c%c%c%c%c%c; Store Register to Memory: Direct addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	// Converts address to integer, then switches based on which register is being stored
	int addr;
	addr = (int) (IR[4] - 48) * 10;
	addr += (int) (IR[5] - 48);
	addr += BAR;
	
	switch( (IR[3] - 48) ) // Switches based on the provided register number, copies appropriate regist to memory line
	{				
		case 0: decToMem(R0, addr);
			break;
		case 1: decToMem(R1, addr);
			break;
		case 2: decToMem(R2, addr);
			break;
		case 3: decToMem(R3, addr);
			break;
	}
	PC ++;
}

// 10 Load Register from Memory (mem to reg): Register addr
void Load_MEM2REG_REG()
{
	printf("IR = %c%c%c%c%c%c; Load Register from Memory (mem to reg): Register addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int addr;
	switch( (IR[5] - 48) ) // Switches based on the provided address register number, after converting char to int
	{				
		case 0: addr = P0 + BAR;
			break;
		case 1: addr = P1 + BAR;
			break;
		case 2: addr = P2 + BAR;
			break;
		case 3: addr = P3 + BAR;
			break;
	}
	switch( (IR[3] - 48) ) // Switches based on the provided register number, copies appropriate regist to memory line
	{				
		case 0: R0 = (memToDec(addr, 1) * 100); // Since memToDec converts a duplet into decimal, converts 1000s and 100s places together... 
				R0 += memToDec(addr, 2);        //  ...followed by 10s and 1s places.
			break;
		case 1: R1 = (memToDec(addr, 1) * 100);
				R1 += memToDec(addr, 2);
			break;
		case 2: R2 = (memToDec(addr, 1) * 100);
				R2 += memToDec(addr, 2);
			break;
		case 3: R3 = (memToDec(addr, 1) * 100);
				R3 += memToDec(addr, 2);
			break;
	}
	PC ++;
}

// 11 Load Register from Memory (mem to reg): Direct addr
void Load_MEM2REG_DIR()
{
	printf("IR = %c%c%c%c%c%c; Load Register from Memory (mem to reg): Direct addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int addr;
	addr = (int) (IR[4] - 48) * 10;
	addr += (int) (IR[5] - 48);
	addr += BAR;
	switch( (IR[3] - 48) ) // Switches based on the provided register number, copies appropriate regist to memory line
	{				
		case 0: R0 = (memToDec(addr, 1) * 100);
				R0 += memToDec(addr, 2);
			break;
		case 1: R1 = (memToDec(addr, 1) * 100);
				R1 += memToDec(addr, 2);
			break;
		case 2: R2 = (memToDec(addr, 1) * 100);
				R2 += memToDec(addr, 2);
			break;
		case 3: R3 = (memToDec(addr, 1) * 100);
				R3 += memToDec(addr, 2);
			break;
	}
	PC ++;
	
}

// 12 Load Register R0: Immediate value
void Load_REGr0_IMM()
{
	printf("IR = %c%c%c%c%c%c; Load Register R0 Immediate (with immediate value)\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	R0 = (IR[2] - 48) * 1000;
	R0 += (IR[3] - 48) * 100;
	R0 += (IR[4] - 48) * 10;
	R0 += (IR[5] - 48);
	PC ++;
}

// 13 Register to Register Transfer
void REG2REG()
{
	printf("IR = %c%c%c%c%c%c; Register to Register Transfer\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int regVal;
	switch( (IR[5] - 48) ) // Switches based on the provided "to be copied" register number, after converting char to int
	{				
		case 0: regVal = R0;
			break;
		case 1: regVal = R1;
			break;
		case 2: regVal = R2;
			break;
		case 3: regVal = R3;
			break;
	}
	
	switch ( (IR[3] - 48) ) // Switches based on the provided "to be set" register number, after converting char to int
	{
		case 0: R0 = regVal;
			break;
		case 1: R1 = regVal;
			break;
		case 2: R2 = regVal;
			break;
		case 3: R3 = regVal;
			break;	
	}
	PC ++;
}

// 14 Load Accumulator from Register (reg to acc)
void Load_REG2ACC()
{
	printf("IR = %c%c%c%c%c%c; Load Accumulator from Register\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	switch( (IR[3] - 48) ) // Switches based on the provided register number, after converting char to int
	{				
		case 0: ACC = R0;
			break;
		case 1: ACC = R1;
			break;
		case 2: ACC = R2;
			break;
		case 3: ACC = R3;
			break;
	}
	PC ++;
}

// 15 Load Register from Accumulator (acc to reg)
void Load_ACC2REG()
{
	printf("IR = %c%c%c%c%c%c; Load Register from Accumulator\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	switch( (IR[3] - 48) ) // Switches based on the provided register number, after converting char to int
	{				
		case 0: R0 = ACC;
			break;
		case 1: R1 = ACC;
			break;
		case 2: R2 = ACC;
			break;
		case 3: R3 = ACC;
			break;
	}
	PC ++;
}

// 16 Add Accumulator: Immediate value
void Add_ACC_IMM()
{
	printf("IR = %c%c%c%c%c%c; Add Accumulator Immediate\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	ACC += (IR[2] - 48) * 1000;
	ACC += (IR[3] - 48) * 100;
	ACC += (IR[4] - 48) * 10;
	ACC += (IR[5] - 48);
	PC ++;
}

// 17 Subtract Accumulator: Immediate value
void Sub_ACC_IMM()
{
	printf("IR = %c%c%c%c%c%c; Subtract Accumulator Immediate\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	ACC -= (IR[2] - 48) * 1000;
	ACC -= (IR[3] - 48) * 100;
	ACC -= (IR[4] - 48) * 10;
	ACC -= (IR[5] - 48);
	PC ++;
}

// 18 Add contents of Register to Accumulator
void Add_REG2ACC()
{
	printf("IR = %c%c%c%c%c%c; Add Contents of Register to Accumulator\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	switch( (IR[5] - 48) ) // Switches based on the provided register number, after converting char to int
	{				
		case 0: ACC += R0;
			break;
		case 1: ACC += R1;
			break;
		case 2: ACC += R2;
			break;
		case 3: ACC += R3;
			break;
	}
	PC ++;
}

// 19 Subtract contents of Register from Accumulator
void Sub_REG_ACC()
{
	printf("IR = %c%c%c%c%c%c; Subtract Contents of Register from Accumulator\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	switch( (IR[5] - 48) ) // Switches based on the provided register number, after converting char to int
	{				
		case 0: ACC -= R0;
			break;
		case 1: ACC -= R1;
			break;
		case 2: ACC -= R2;
			break;
		case 3: ACC -= R3;
			break;
	}
	PC ++;
}

// 20 Add Accumulator: Register addr
void Add_2ACC_REG()
{
	printf("IR = %c%c%c%c%c%c; Add Accumulator: Register addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	int i;
	char memLine[6]; 
	switch( (IR[3] - 48) ) // Switches based on the provided register number, after converting char to int
	{	// Copies the appropriate line of memory into a variable
		case 0: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P0 + BAR][i]; 
			}
			break;
		case 1: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P1 + BAR][i]; 
			}
			break;
		case 2: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P2 + BAR][i]; 
			}
			break;
		case 3: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P3 + BAR][i]; 
			}
			break;
	}
	// Converts the data stored on memory line to int, then adds to accumulator
	ACC += (int) (memLine[2] - 48) * 1000;
	ACC += (int) (memLine[3] - 48) * 100; 
	ACC += (int) (memLine[4] - 48) * 10;
	ACC += (int) (memLine[5] - 48);
	PC ++;
}

// 21 Add Accumulator: Direct addr
void Add_2ACC_DIR()
{
	printf("IR = %c%c%c%c%c%c; Add Accumulator: Direct addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	// Gets the memory address from the instruction, converts to int
	int addr = (int) (IR[2] - 48) * 10;
	addr += (int) (IR[2] - 48);
	addr += BAR;
	
	// Converts data from memory line to int, then adds to accumulator
	ACC += (int) (memory[addr][2] - 48) * 1000;
	ACC += (int) (memory[addr][3] - 48) * 100; 
	ACC += (int) (memory[addr][4] - 48) * 10;
	ACC += (int) (memory[addr][5] - 48);
	PC ++;
}

// 22 Subtract from Accumulator: Register addr
void Sub_ACC_REG()
{
	printf("IR = %c%c%c%c%c%c; Subtract from Accumulator: Register addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	int i;
	char memLine[6]; 
	switch( (IR[3] - 48) ) // Switches based on the provided register number, after converting char to int
	{	// Copies the appropriate line of memory into a variable
		case 0: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P0 + BAR][i]; 
			}
			break;
		case 1: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P1 + BAR][i]; 
			}
			break;
		case 2: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P2 + BAR][i]; 
			}
			break;
		case 3: for (i = 0; i < 6; i++)
			{	
				memLine[i] = memory[P3 + BAR][i]; 
			}
			break;
	}
	// Converts the data stored on memory line to int, then subtracts from accumulator
	ACC -= (int) (memLine[2] - 48) * 1000;
	ACC -= (int) (memLine[3] - 48) * 100; 
	ACC -= (int) (memLine[4] - 48) * 10;
	ACC -= (int) (memLine[5] - 48);
	PC ++;
}

// 23 Subtract from Accumulator: Direct addr
void Sub_ACC_DIR()
{
	printf("IR = %c%c%c%c%c%c; Subtract from Accumulator: Direct addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	
	// Gets the memory address from the instruction, converts to int
	int addr = (int) (IR[2] - 48) * 10;
	addr += (int) (IR[2] - 48);
	addr += BAR;
	
	// Converts data from memory line to int, then adds to accumulator
	ACC -= (int) (memory[addr][2] - 48) * 1000;
	ACC -= (int) (memory[addr][3] - 48) * 100; 
	ACC -= (int) (memory[addr][4] - 48) * 10;
	ACC -= (int) (memory[addr][5] - 48);
	PC ++;
}

// 24 Compare Equal: Register addr
void Comp_EQL_REG()
{
	printf("IR = %c%c%c%c%c%c; Compare Equal: Register addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int addr;
	int value;
	char val = 'F';
	switch( (IR[5] - 48) ) // Switches based on the provided address register number, after converting char to int
	{				
		case 0: addr = P0 + BAR;
			break;
		case 1: addr = P1 + BAR;
			break;
		case 2: addr = P2 + BAR;
			break;
		case 3: addr = P3 + BAR;
			break;
	}
	value = (memToDec(addr, 1) * 100); // Since memToDec converts a duplet into decimal, converts 1000s and 100s places together... 
	value += memToDec(addr, 2);        //  ...followed by 10s and 1s places.
	if (ACC == value){val = 'T';}      // checks if accumulator is equal to value held in memory...
	PSW[0] = val;					   //  ...and sets the Process Status Word accordingly
	PC ++;
}

// 25 Compare Less: Register addr
void Comp_LESS_REG()
{
	printf("IR = %c%c%c%c%c%c; Compare Less: Register addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int addr;
	int value;
	char val = 'F';
	switch( (IR[5] - 48) ) // Switches based on the provided address register number, after converting char to int
	{				
		case 0: addr = P0 + BAR;
			break;
		case 1: addr = P1 + BAR;
			break;
		case 2: addr = P2 + BAR;
			break;
		case 3: addr = P3 + BAR;
			break;
	}
	value = (memToDec(addr, 1) * 100); // Since memToDec converts a duplet into decimal, converts 1000s and 100s places together... 
	value += memToDec(addr, 2);        //  ...followed by 10s and 1s places.
	if (ACC < value){val = 'T';}       // checks if accumulator is less than value held in memory...
	PSW[0] = val;					   //  ...and sets the Process Status Word accordingly
	PC ++;
}

// 26 Compare Greater: Register addr
void Comp_GRT_REG()
{
	printf("IR = %c%c%c%c%c%c; Compare Greater: Register addr\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int addr;
	int value;
	char val = 'F';
	switch( (IR[5] - 48) ) // Switches based on the provided address register number, after converting char to int
	{				
		case 0: addr = P0 + BAR;
			break;
		case 1: addr = P1 + BAR;
			break;
		case 2: addr = P2 + BAR;
			break;
		case 3: addr = P3 + BAR;
			break;
	}
	value = (memToDec(addr, 1) * 100); // Since memToDec converts a duplet into decimal, converts 1000s and 100s places together... 
	value += memToDec(addr, 2);        //  ...followed by 10s and 1s places.
	if (ACC > value){val = 'T';}       // checks if accumulator is greater than value held in memory...
	PSW[0] = val;					   //  ...and sets the Process Status Word accordingly
	PC ++;
}

// 27 Compare Greater: Immediate value
void Comp_GRT_IMM()
{
	printf("IR = %c%c%c%c%c%c; Compare Greater: Immediate value\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int value;
	char val = 'F';
	value= (IR[2] - 48) * 1000;
	value += (IR[3] - 48) * 100;
	value += (IR[4] - 48) * 10;
	value += (IR[5] - 48);
	if (ACC > value){val = 'T';}       // checks if accumulator is greater than immediate value...
	PSW[0] = val;					   //  ...and sets the Process Status Word accordingly
	PC ++;
}

// 28 Compare Equal: Immediate value
void Comp_EQL_IMM()
{
	printf("IR = %c%c%c%c%c%c; Compare Equal: Immediate value\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int value;
	char val = 'F';
	value= (IR[2] - 48) * 1000;
	value += (IR[3] - 48) * 100;
	value += (IR[4] - 48) * 10;
	value += (IR[5] - 48);
	if (ACC == value){val = 'T';}       // checks if accumulator is equal to immediate value...
	PSW[0] = val;					    //  ...and sets the Process Status Word accordingly
	PC ++;
}

// 29 Compare Less: Immediate value
void Comp_LESS_IMM()
{
	printf("IR = %c%c%c%c%c%c; Compare Less: Immediate value\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int value;
	char val = 'F';
	value= (IR[2] - 48) * 1000;
	value += (IR[3] - 48) * 100;
	value += (IR[4] - 48) * 10;
	value += (IR[5] - 48);
	if (ACC < value){val = 'T';}       // checks if accumulator is less than immediate value...
	PSW[0] = val;					   //  ...and sets the Process Status Word accordingly
	PC ++;
}

// 30 Compare Register Equal
void Comp_REG_EQL()
{
	printf("IR = %c%c%c%c%c%c; Compare Register Equal\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int Rn = IR[3] - 48; // converts char of register number to int
	char val = 'F';
	switch(Rn)
	{
		case 0: if (ACC == R0) {val = 'T';}
			break;
		case 1: if (ACC == R1) {val = 'T';}
			break;
		case 2: if (ACC == R2) {val = 'T';}
			break;
		case 3: if (ACC == R3) {val = 'T';}
			break;
	}
	PSW[0] = val;
	PC ++;
}

// 31 Compare Register Less
void Comp_REG_LESS()
{
	printf("IR = %c%c%c%c%c%c; Compare Register Less\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int Rn = IR[3] - 48; // converts char of register number to int
	char val = 'F';
	switch(Rn)
	{
		case 0: if (ACC < R0) {val = 'T';}
			break;
		case 1: if (ACC < R1) {val = 'T';}
			break;
		case 2: if (ACC < R2) {val = 'T';}
			break;
		case 3: if (ACC < R3) {val = 'T';}
			break;
	}
	PSW[0] = val;
	PC ++;
}

// 32 Compare Register Greater
void Comp_REG_GRT()
{
	printf("IR = %c%c%c%c%c%c; Compare Register Greater\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int Rn = IR[3] - 48; // converts char of register number to int
	char val = 'F';
	switch(Rn)
	{
		case 0: if (ACC > R0) {val = 'T';}
			break;
		case 1: if (ACC > R1) {val = 'T';}
			break;
		case 2: if (ACC > R2) {val = 'T';}
			break;
		case 3: if (ACC > R3) {val = 'T';}
			break;
	}
	PSW[0] = val;
	PC ++;
}

// 33 Branch Conditional: True
void Branch_Cond_T()
{
	printf("IR = %c%c%c%c%c%c; Branch Conditional: True\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	if (PSW[0] == 'T')
	{
		int newCount;
		newCount = (int) (IR[2] - 48) * 10;
		newCount += (int) (IR[3] - 48);
		PC = newCount;
	}
	else {PC ++;}
}

// 34 Branch Conditional: False
void Branch_Cond_F()
{
	printf("IR = %c%c%c%c%c%c; Branch Conditional: False\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	if (PSW[0] == 'F')
	{
		int newCount;
		newCount = (int) (IR[2] - 48) * 10;
		newCount += (int) (IR[3] - 48);
		PC = newCount;
	}
	else {PC ++;}
}

// 35 Branch Unconditional
void Branch_Uncond()
{
	printf("IR = %c%c%c%c%c%c; Branch Unconditional\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int newCount;
	newCount = (int) (IR[2] - 48) * 10;
	newCount += (int) (IR[3] - 48);
	PC = newCount;
}

// 36 Trap
void Trap()
{
	printf("IR = %c%c%c%c%c%c; Trap: ", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);	
	int reg1, sysCall;
	reg1 = (IR[3] -48);
	switch (reg1)  	  // switches based on which register the system call value is stored in
	{
		case 0: sysCall = R0;
			break;
		case 1: sysCall = R1;
			break;
		case 2: sysCall = R2;
			break;
		case 3: sysCall = R3;
			break;
	}
	PC ++;            // incrments PC before switch in case of "wait" sysCall -- want to save accurate PC value 
	                  // before possibly placing PCB on Sem_Q

	switch (sysCall)  // Switches based on which system call the Trap() command issued
	{
		case 0: printf("Wait on ");
			semaWait();
			break;
		case 1: printf("Signal ");
			semaSignal();
			break;
		case 2: printf("Get PID.");
			getPID();
			break;
	}
}

// system call 0
void semaWait()
{	
	int semType, reg2;
	reg2 = (IR[5] -48);
	switch (reg2)
	{
		case 0: semType = R0;
			break;
		case 1: semType = R1;
			break;
		case 2: semType = R2;
			break;
		case 3: semType = R3;
			break;
	}
	
	if (semType == 1)  // if the semaphore type is Doorman
	{
		printf("the Doorman.  ");
		Doorman->count --;
		if (Doorman->count < 0)             // if count < 0, then this PCB goes on Sem_Q
		{
			printf("PID %d blocked on Doorman!", currentPID);
			save_VM_to_PCB();               // saves current VM state to PCB
			
			struct PCB *x;
			x = Doorman->Sem_Q;
			
			if (x == NULL)     // if Sem_Q is empty, this is first PCB on it!
			{
				Doorman->Sem_Q = RQ;
				x = Doorman->Sem_Q;
			}
			else                            // otherwise ...
			{
				while (x->Next_PCB != NULL) // ... cycle through the Sem_Q until find the last one ...
				{
					x = x->Next_PCB;
				}
				x->Next_PCB = RQ;           // and add this PCB to the end!
				x = x->Next_PCB;            // sets x to be the current PCB
			} // end of else
			RQ = RQ->Next_PCB;              // Progresses the RQ ...
			RQT->Next_PCB = RQ;             // ... and points the tail to the new head.
			x->Next_PCB = NULL;             // Tells the current PCB it's the tail of the Sem_Q
		} // end of if(count < 0) -- done with wait command on Doorman 
		
	} // end of if(semType == 1) 
	
	else // otherwise the semaphore type is Forks[]
	{
		int forkIndex;
		forkIndex = ACC;                        // gets the fork index stored in the ACC -- subtracts 1 for C-style index
		printf("Fork #%d.  ", forkIndex); 
		Forks[forkIndex]->count --; 
		
		if (Forks[forkIndex]->count < 0)             // if count < 0, then this PCB goes on Sem_Q
		{
			printf("PID %d blocked on Fork #%d!", currentPID, forkIndex);
			save_VM_to_PCB();                        // saves current VM state to PCB
			
			struct PCB *x;
			x = Forks[forkIndex]->Sem_Q;
			
			if (x == NULL)     // if Sem_Q is empty, this is first PCB on it!
			{
				Forks[forkIndex]->Sem_Q = RQ;
				x = Forks[forkIndex]->Sem_Q;
			}
			else                                     // otherwise ...
			{
				while (x->Next_PCB != NULL)          // ... cycle through the Sem_Q until find the last one ...
				{
					x = x->Next_PCB;
				}
				x->Next_PCB = RQ;                    // and add this PCB to the end!
				x = x->Next_PCB;                     // sets x to be the current PCB
			} // end of else
			RQ = RQ->Next_PCB;                       // Progresses the RQ ...
			RQT->Next_PCB = RQ;                      // ... and points the tail to the new head.
			x->Next_PCB = NULL;                      // Tells the current PCB it's the tail of the Sem_Q
		} // end of if(count < 0) -- done with wait command on Forks[]	
	} 
	printf("\n"); // adds newline character to compound print statement
}

// system call 1
void semaSignal()
{	
	int semType, reg2;
	reg2 = (IR[5] -48);
	switch (reg2)
	{
		case 0: semType = R0;
			break;
		case 1: semType = R1;
			break;
		case 2: semType = R2;
			break;
		case 3: semType = R3;
			break;
	}

	if (semType == 1)                                // if semaphore type is Doorman ... 
	{
		printf("the Doorman.  ");
		Doorman->count ++;
		
		if (Doorman->count <= 0)                     // if there are other processes waiting on semaphore, place next one on RQ
		{
			printf("PID %d has been placed on the RQ due to signal on the Doorman.", RQT->PID);
			RQT = Doorman->Sem_Q;
			RQT->Next_PCB = RQ;
			Doorman->Sem_Q = Doorman->Sem_Q->Next_PCB;
		}
	}
	else                                             // ... otherwise semaphore type is Forks[]
	{
		int forkIndex = ACC;                         // gets the fork index stored in the ACC	
		printf("Fork #%d.  ", forkIndex);
		Forks[forkIndex]->count ++;
		
		if (Forks[forkIndex]->count <= 0)            // if there are other processes waiting on semaphore, place next one on RQ
		{
			RQT = Forks[forkIndex]->Sem_Q;
			RQT->Next_PCB = RQ;
			Forks[forkIndex]->Sem_Q = Forks[forkIndex]->Sem_Q->Next_PCB;
			printf("PID %d has been placed on the RQ due to signal on Fork#%d.", RQT->PID, forkIndex);
		}
	} // end of else 
	printf("\n");
}

// system call 2
void getPID()
{
	int reg2;
	reg2 = (IR[5] -48); // only if wait or signal
	switch (reg2)
	{
		case 0: R0 = currentPID;
			break;
		case 1: R1 = currentPID;
			break;
		case 2: R2 = currentPID;
			break;
		case 3: R3 = currentPID;
			break;
	}
	printf("\n");
}

// 37 Modulus 
void Mod()
{
	printf("IR = %c%c%c%c%c%c; Modulus\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	int x, y;
	int reg1, reg2;
	reg1 = (IR[3] -48); 
	reg2 = (IR[5] -48); 
	switch (reg1)
	{
		case 0: x = R0;
			break;
		case 1: x = R1;
			break;
		case 2: x = R2;
			break;
		case 3: x = R3;
			break;
	}
	switch (reg2)
	{
		case 0: y = R0;
			break;
		case 1: y = R1;
			break;
		case 2: y = R2;
			break;
		case 3: y = R3;
			break;
	}
	ACC = (x % y);
	PC ++;
}

// 99 Halt
void Halt() 
{
	printf("IR = %c%c%c%c%c%c; HALT\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	/*
	int i;
	printf("\nCPU:\n");
	printf("PC=%03d ACC=%4d PSW=%c IR=%c%c%c%c%c%c\n", PC, ACC, PSW[0], IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	printf("\nREGISTERS:\n");
	printf("P0=%02d   P1=%02d   P2=%02d   P3=%02d \nR0=%04d R1=%04d R2=%04d R3=%04d\n", P0, P1, P2, P3, R0, R1, R2, R3);
	printf("BAR = %03d EAR = %03d LR = %03d IC = %02d\n", BAR, EAR, LR, IC);
	printf("\nMEMORY:\n");
	for (i = BAR; i < LR; i+= 10)
	{		
		printf("%2d: %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c\n", i, 
		memory[i][0], memory[i][1], memory[i][2], memory[i][3], memory[i][4], memory[i][5],
		memory[i+1][0], memory[i+1][1], memory[i+1][2], memory[i+1][3], memory[i+1][4], memory[i+1][5], 
		memory[i+2][0], memory[i+2][1], memory[i+2][2], memory[i+2][3], memory[i+2][4], memory[i+2][5],
		memory[i+3][0], memory[i+3][1], memory[i+3][2], memory[i+3][3], memory[i+3][4], memory[i+3][5], 
		memory[i+4][0], memory[i+4][1], memory[i+4][2], memory[i+4][3], memory[i+4][4], memory[i+4][5],
		memory[i+5][0], memory[i+5][1], memory[i+5][2], memory[i+5][3], memory[i+5][4], memory[i+5][5],
		memory[i+6][0], memory[i+6][1], memory[i+6][2], memory[i+6][3], memory[i+6][4], memory[i+6][5], 
		memory[i+7][0], memory[i+7][1], memory[i+7][2], memory[i+7][3], memory[i+7][4], memory[i+7][5], 
		memory[i+8][0], memory[i+8][1], memory[i+8][2], memory[i+8][3], memory[i+8][4], memory[i+8][5],
		memory[i+9][0], memory[i+9][1], memory[i+9][2], memory[i+9][3], memory[i+9][4], memory[i+9][5]);
	}*/
	printf("PID:%d (%c%c%c%c) has finished executing!\n\n", currentPID, RQ->progName[0], RQ->progName[1], RQ->progName[2], RQ->progName[3]);
	IC = -1;
}

// Ends the VM, prints total machine status
int shutDown()
{
	printf("Shutting down.\n\n********* ENDING VM STATE *********\n");
	int i;
	printf("\nCPU:\n");
	printf("PC=%03d ACC=%04d PSW=%c IR=%c%c%c%c%c%c\n", PC, ACC, PSW[0], IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	printf("\nREGISTERS:\n");
	printf("IR = %c%c%c%c%c%c\n", IR[0], IR[1], IR[2], IR[3], IR[4], IR[5]);
	printf("P0=%02d   P1=%02d   P2=%02d   P3=%02d \nR0=%04d R1=%04d R2=%04d R3=%04d\n", P0, P1, P2, P3, R0, R1, R2, R3);
	printf("BAR = %03d  EAR = %03d  LR = %03d\n", BAR, EAR, LR);
	printf("\nMEMORY:\n");
	for (i = 0; i < memSize; i+= 10)
	{
		if (i % 100 == 0) // Separates each 100-word chunk of memory by dash-lines
		{
			printf("-----------------------------------------------------------------------------------\n");
		}
	
		printf("%2d: %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c  %c%c%c%c%c%c\n", i, 
		memory[i][0], memory[i][1], memory[i][2], memory[i][3], memory[i][4], memory[i][5],
		memory[i+1][0], memory[i+1][1], memory[i+1][2], memory[i+1][3], memory[i+1][4], memory[i+1][5], 
		memory[i+2][0], memory[i+2][1], memory[i+2][2], memory[i+2][3], memory[i+2][4], memory[i+2][5],
		memory[i+3][0], memory[i+3][1], memory[i+3][2], memory[i+3][3], memory[i+3][4], memory[i+3][5], 
		memory[i+4][0], memory[i+4][1], memory[i+4][2], memory[i+4][3], memory[i+4][4], memory[i+4][5],
		memory[i+5][0], memory[i+5][1], memory[i+5][2], memory[i+5][3], memory[i+5][4], memory[i+5][5],
		memory[i+6][0], memory[i+6][1], memory[i+6][2], memory[i+6][3], memory[i+6][4], memory[i+6][5], 
		memory[i+7][0], memory[i+7][1], memory[i+7][2], memory[i+7][3], memory[i+7][4], memory[i+7][5], 
		memory[i+8][0], memory[i+8][1], memory[i+8][2], memory[i+8][3], memory[i+8][4], memory[i+8][5],
		memory[i+9][0], memory[i+9][1], memory[i+9][2], memory[i+9][3], memory[i+9][4], memory[i+9][5]);
	}
	exit(1);
}




